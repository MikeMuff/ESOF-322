package utils;

public abstract class StoreStrategy{
	
	public abstract void store();
}